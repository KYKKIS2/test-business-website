# PRD

## Summary
Describe the product or feature at a high level.

## Problem
What problem are we solving?

## Goals
- Goal 1
- Goal 2

## Non-Goals
- Non-goal 1

## Users
Who are the primary users?

## Functional Requirements
- FR1
- FR2

## Non-Functional Requirements
- Performance:
- Reliability:
- Security:

## Success Metrics
- Metric 1
- Metric 2

## Milestones
- Milestone 1
- Milestone 2

## Out of Scope
- Item 1
